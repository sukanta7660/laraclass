<!DOCTYPE html>
<html>
<head>
	<title>This is first try</title>
</head>
<body>
	<h1 style="color: red">Hellow Admin</h1>
</body>
</html><?php /**PATH C:\laragon\www\laraclass\resources\views/admin/adminhome.blade.php ENDPATH**/ ?>