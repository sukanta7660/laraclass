<?php $__env->startSection('title','Category'); ?>
<?php $__env->startSection('content'); ?>
<h1 class="h3 mb-1 text-gray-800">All Category</h1><br>
<div class="card shadow mb-4">
            <div class="card-header py-3">
            <h6 class="m-0 font-weight-bold text-primary"><a href="<?php echo e(action('IndexController@create_category_page')); ?>" class="btn btn-sm btn-primary">Create</a></h6>
            </div>
            <div class="card-body">
            <table class="table">
              <thead class="thead-light">
                <tr>
                  <th scope="col">#</th>
                  <th scope="col">Category Name</th>
                  <th class="text-right">Action</th>
                </tr>
              </thead>
              <tbody>
                <?php
                    $i = 1;
                ?>
                <?php $__currentLoopData = $cat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                    <th scope="row"><?php echo e($i++); ?></th>
                    <td><?php echo e($item->name); ?></td>
                  <td class="text-right">
                    <a href="#" class="btn btn-sm btn-primary">Edit</a> || <a href="" class="btn btn-sm btn-danger">Del</a>
                  </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </tbody>
            </table>
            <?php echo e($cat->links()); ?>

            </div>
          </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.admin_master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\laraclass\resources\views/admin/category.blade.php ENDPATH**/ ?>