<footer class="sticky-footer bg-white">
        <div class="container my-auto">
          <div class="copyright text-center my-auto">
            <span>Copyright &copy; SuperBlog <?php echo e(date('Y')); ?></span>
          </div>
        </div>
      </footer><?php /**PATH C:\laragon\www\laraclass\resources\views/shared/admin/footer.blade.php ENDPATH**/ ?>