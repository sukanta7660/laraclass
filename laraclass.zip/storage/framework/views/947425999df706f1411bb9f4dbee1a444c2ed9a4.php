<?php $__env->startSection('title','Example'); ?>
<?php $__env->startSection('content'); ?>
<h1 class="h3 mb-1 text-gray-800">Example Page</h1>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.admin_master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\laraclass\resources\views/admin/example.blade.php ENDPATH**/ ?>