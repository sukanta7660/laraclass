<?php $__env->startSection('title'); ?>
Dashboard
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<h1 class="h3 mb-1 text-gray-800">Dashboard</h1>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.admin_master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\laraclass\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>