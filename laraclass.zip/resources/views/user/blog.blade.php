@extends('layout.master')
@section('style')
<style type="text/css">
	.cls{
		color: green;
	}
</style>
@endsection
@section('content')
 <h3 class="cls">I am blog page</h3>
@endsection