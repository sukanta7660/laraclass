@extends('layout.admin_master')
@section('title')
Dashboard
@endsection
@section('content')
<h1 class="h3 mb-1 text-gray-800">Dashboard</h1>
@endsection